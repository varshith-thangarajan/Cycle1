import java.util.*;
public class Main
{
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.print("Enter the number:");
int n=sc.nextInt();
int r=0;
while(n!=0){
int rem=n%10;
n=n/10;
r=r*10+rem;
}
System.out.println("Reverse of a number:"+r);
}
}