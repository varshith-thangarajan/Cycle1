import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
	int i, j, k, n;
	Scanner sc = new Scanner (System.in);
	  System.out.print ("Enter the no of rows: ");
	  n = sc.nextInt ();
	for (i = 1; i <= n; i++)
	  {
		for (j = i; j < n; j++)
		  {
			System.out.print (" ");
		  }
		for (k = 1; k <= (2 * i - 1); k++)
		  {
			if (k == 1 || i == n || k == (2 * i - 1))
			  {
				System.out.print ("*");
			  }
			else
			  {
				System.out.print (" ");
			  }
		  }
		System.out.println ("");
	  }
  }
}
