import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the array length: ");
        int n = sc.nextInt();
        System.out.print("Enter the array elements: ");
        int[] candies = new int[n];
        for(int i=0; i<n; i++){
            candies[i] = sc.nextInt();
        }
        int extraCandies = 3;
        ArrayList<Boolean> res = new ArrayList<Boolean>(candies.length);
        int[] arr = new int[candies.length];
        for(int i=0; i<candies.length; i++){
            arr[i] = candies[i] + extraCandies;
        }
        int max=0;
        for(int i=0; i<candies.length; i++){
            if(candies[i] > max){
                max = arr[i];
            }
        }
        for(int i=0; i<candies.length; i++){
            if(arr[i] >= max){
                res.add(true);
            }
            else{
                res.add(false);
            }
        }
        System.out.print(res);
    }
}